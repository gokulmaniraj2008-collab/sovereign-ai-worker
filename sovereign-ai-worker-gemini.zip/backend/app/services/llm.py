import httpx
from app.config import settings


class LLMProvider:
    def generate(self, prompt: str) -> str:
        raise NotImplementedError


class LocalLLMProvider(LLMProvider):
    """Calls a local Ollama server. Only reachable when Ollama runs on the
    same host as the API (local Docker dev, or a self-hosted deployment)."""

    def generate(self, prompt: str) -> str:
        r = httpx.post(
            f"{settings.ollama_base_url.rstrip('/')}/api/generate",
            json={"model": settings.ollama_model, "prompt": prompt, "stream": False},
            timeout=180,
        )
        r.raise_for_status()
        return r.json()["response"].strip()


class GeminiLLMProvider(LLMProvider):
    """Calls the hosted Google Gemini API (generateContent)."""

    def generate(self, prompt: str) -> str:
        if not settings.gemini_api_key.strip():
            raise RuntimeError(
                "GEMINI_API_KEY is not set. Add it in the Render environment "
                "variables (Dashboard -> service -> Environment)."
            )
        url = (
            "https://generativelanguage.googleapis.com/v1beta/models/"
            f"{settings.gemini_model}:generateContent"
        )
        r = httpx.post(
            url,
            headers={
                "x-goog-api-key": settings.gemini_api_key,
                "Content-Type": "application/json",
            },
            json={"contents": [{"parts": [{"text": prompt}]}]},
            timeout=120,
        )
        r.raise_for_status()
        data = r.json()
        try:
            return data["candidates"][0]["content"]["parts"][0]["text"].strip()
        except (KeyError, IndexError, TypeError) as exc:
            raise RuntimeError(f"Unexpected Gemini response shape: {data}") from exc


def _build_provider() -> LLMProvider:
    provider = settings.llm_provider.strip().lower()
    if provider == "gemini":
        return GeminiLLMProvider()
    if provider == "ollama":
        return LocalLLMProvider()
    raise RuntimeError(
        f"Unknown LLM_PROVIDER '{settings.llm_provider}'. Use 'ollama' or 'gemini'."
    )


llm_provider = _build_provider()
