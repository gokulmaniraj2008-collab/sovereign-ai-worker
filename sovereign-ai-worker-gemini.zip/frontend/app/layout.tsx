import './globals.css';
export const metadata = { title: 'SovereignAI Worker', description: 'Local document processing with hybrid AI (Google Gemini for answer generation)' };
export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) { return <html lang="en"><body>{children}</body></html>; }
